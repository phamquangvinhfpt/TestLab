# Go Docker MySQL
In this tutorial, I show you how to set up a Golang API with a database powered by Docker. 